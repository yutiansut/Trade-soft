﻿using System;
using System.Collections.Generic;
using System.Data;
using QuantBox.CSharp2CTPZQ;
using SmartQuant;
using SmartQuant.Execution;
using SmartQuant.FIX;
using SmartQuant.Providers;
using System.Reflection;

namespace QuantBox.OQ.CTPZQ
{
    public partial class CTPZQProvider : IExecutionProvider
    {
        private Dictionary<SingleOrder, OrderRecord> orderRecords = new Dictionary<SingleOrder, OrderRecord>();

        public event ExecutionReportEventHandler ExecutionReport;
        public event OrderCancelRejectEventHandler OrderCancelReject;

        public BrokerInfo GetBrokerInfo()
        {
            BrokerInfo brokerInfo = new BrokerInfo();

            if (IsConnected)
            {
                tdlog.Info("GetBrokerInfo");
                //TraderApi.TD_ReqQryTradingAccount(m_pTdApi);
                //TraderApi.TD_ReqQryInvestorPosition(m_pTdApi, null);
                //timerAccount.Enabled = false;
                //timerAccount.Enabled = true;
                //timerPonstion.Enabled = false;
                //timerPonstion.Enabled = true;    

                BrokerAccount brokerAccount = new BrokerAccount(m_TradingAccount.AccountID);

                // account fields
                brokerAccount.BuyingPower = m_TradingAccount.Available;

                Type t = typeof(CZQThostFtdcTradingAccountField);
                FieldInfo[] fields = t.GetFields(BindingFlags.Public | BindingFlags.Instance);
                foreach (FieldInfo field in fields)
                {
                    brokerAccount.AddField(field.Name, field.GetValue(m_TradingAccount).ToString());
                }

                DataRow[] rows = _dbInMemInvestorPosition.SelectAll();

                foreach (DataRow dr in rows)
                {
                    BrokerPosition brokerPosition = new BrokerPosition {
                        Symbol = dr[DbInMemInvestorPosition.InstrumentID].ToString()
                    };

                    int pos = (int)dr[DbInMemInvestorPosition.Position];
                    
                    TZQThostFtdcPosiDirectionType PosiDirection = (TZQThostFtdcPosiDirectionType)dr[DbInMemInvestorPosition.PosiDirection];
                    if (TZQThostFtdcPosiDirectionType.Long == PosiDirection)
                    {
                        brokerPosition.LongQty = pos;
                    }
                    else if (TZQThostFtdcPosiDirectionType.Short == PosiDirection)
                    {
                        brokerPosition.ShortQty = pos;
                    }
                    else
                    {
                        if (pos >= 0)//净NET这个概念是什么情况？
                            brokerPosition.LongQty = pos;
                        else
                            brokerPosition.ShortQty = -pos;
                    }
                    brokerPosition.Qty = brokerPosition.LongQty - brokerPosition.ShortQty;
                    brokerPosition.AddCustomField(DbInMemInvestorPosition.PosiDirection, PosiDirection.ToString());
                    brokerPosition.AddCustomField(DbInMemInvestorPosition.HedgeFlag, ((TZQThostFtdcHedgeFlagType)dr[DbInMemInvestorPosition.HedgeFlag]).ToString());
                    brokerPosition.AddCustomField(DbInMemInvestorPosition.PositionDate, ((TZQThostFtdcPositionDateType)dr[DbInMemInvestorPosition.PositionDate]).ToString());
                    brokerPosition.AddCustomField(DbInMemInvestorPosition.LongFrozen, dr[DbInMemInvestorPosition.LongFrozen].ToString());
                    brokerPosition.AddCustomField(DbInMemInvestorPosition.ShortFrozen, dr[DbInMemInvestorPosition.ShortFrozen].ToString());
                    brokerAccount.AddPosition(brokerPosition);
                }
                brokerInfo.Accounts.Add(brokerAccount);
            }            

            return brokerInfo;
        }

        public void SendNewOrderSingle(NewOrderSingle order)
        {
            SingleOrder key = order as SingleOrder;
            this.orderRecords.Add(key, new OrderRecord(key));
            Send(key);
        }

        #region OpenQuant下的接口
        public void SendOrderCancelReplaceRequest(OrderCancelReplaceRequest request)
        {
            SendOrderCancelReplaceRequest(request as FIXOrderCancelReplaceRequest);
        }

        public void SendOrderCancelRequest(OrderCancelRequest request)
        {
            SendOrderCancelRequest(request as FIXOrderCancelRequest);
        }

        public void SendOrderStatusRequest(OrderStatusRequest request)
        {
            SendOrderStatusRequest(request as FIXOrderStatusRequest);
        }
        #endregion

        #region QuantDeveloper下的接口
        public void SendOrderCancelReplaceRequest(FIXOrderCancelReplaceRequest request)
        {
            //IOrder order = OrderManager.Orders.All[request.OrigClOrdID];
            //SingleOrder order2 = order as SingleOrder;
            //this.provider.CallReplace(order2);
            EmitError(-1,-1,"不支持改单指令");
        }

        public void SendOrderCancelRequest(FIXOrderCancelRequest request)
        {
            IOrder order = OrderManager.Orders.All[request.OrigClOrdID];
            SingleOrder order2 = order as SingleOrder;
            Cancel(order2);
        }

        public void SendOrderStatusRequest(FIXOrderStatusRequest request)
        {
            throw new NotImplementedException();
        }
        #endregion

        private void EmitExecutionReport(ExecutionReport report)
        {
            if (ExecutionReport != null)
            {
                ExecutionReport(this, new ExecutionReportEventArgs(report));
            }
        }

        private void EmitOrderCancelReject()
        {
            if (OrderCancelReject != null)
            {
                OrderCancelReject(this, new OrderCancelRejectEventArgs(null));
            }
        }

        public void EmitExecutionReport(SingleOrder order, OrdStatus status)
        {
            EmitExecutionReport(order, status, "");
        }

        public void EmitExecutionReport(SingleOrder order, OrdStatus status, string text)
        {
            OrderRecord record = this.orderRecords[order];
            EmitExecutionReport(record, status, 0.0, 0, text);
        }

        public void EmitExecutionReport(SingleOrder order, double price, int quantity)
        {
            OrderRecord record = this.orderRecords[order];
            EmitExecutionReport(record, OrdStatus.Undefined, price, quantity, "");
        }

        private void EmitExecutionReport(OrderRecord record, OrdStatus ordStatus, double lastPx, int lastQty, string text)
        {
            ExecutionReport report = new ExecutionReport
            {
                TransactTime = Clock.Now,
                ClOrdID = record.Order.ClOrdID,
                OrigClOrdID = record.Order.ClOrdID,
                OrderID = record.Order.OrderID,
                Symbol = record.Order.Symbol,
                SecurityType = record.Order.SecurityType,
                SecurityExchange = record.Order.SecurityExchange,
                Currency = record.Order.Currency,
                Side = record.Order.Side,
                OrdType = record.Order.OrdType,
                TimeInForce = record.Order.TimeInForce,
                OrderQty = record.Order.OrderQty,
                Price = record.Order.Price,
                StopPx = record.Order.StopPx,
                LastPx = lastPx,
                LastQty = lastQty
            };
            if (ordStatus == OrdStatus.Undefined)
            {
                record.AddFill(lastPx, lastQty);
                if (record.LeavesQty > 0)
                {
                    ordStatus = OrdStatus.PartiallyFilled;
                }
                else
                {
                    ordStatus = OrdStatus.Filled;
                }
            }
            report.AvgPx = record.AvgPx;
            report.CumQty = record.CumQty;
            report.LeavesQty = record.LeavesQty;
            report.ExecType = this.GetExecType(ordStatus);
            report.OrdStatus = ordStatus;
            report.Text = text;

            EmitExecutionReport(report);
        }

        protected void EmitAccepted(SingleOrder order)
        {
            EmitExecutionReport(order, OrdStatus.New);
        }

        protected void EmitCancelled(SingleOrder order)
        {
            EmitExecutionReport(order, OrdStatus.Cancelled);
        }

        protected void EmitCancelReject(SingleOrder order, string message)
        {
            //EmitCancelReject(order, message);
        }

        protected void EmitFilled(SingleOrder order, double price, int quantity)
        {
            EmitExecutionReport(order, price, quantity);
        }

        protected void EmitRejected(SingleOrder order, string message)
        {
            EmitExecutionReport(order, OrdStatus.Rejected, message);
        }

        private ExecType GetExecType(OrdStatus status)
        {
            switch (status)
            {
                case OrdStatus.New:
                    return ExecType.New;
                case OrdStatus.PartiallyFilled:
                    return ExecType.PartialFill;
                case OrdStatus.Filled:
                    return ExecType.Fill;
                case OrdStatus.Cancelled:
                    return ExecType.Cancelled;
                case OrdStatus.Replaced:
                    return ExecType.Replace;
                case OrdStatus.PendingCancel:
                    return ExecType.PendingCancel;
                case OrdStatus.Rejected:
                    return ExecType.Rejected;
                case OrdStatus.PendingReplace:
                    return ExecType.PendingReplace;
            }
            throw new ArgumentException(string.Format("Cannot find exec type for ord status - {0}", status));
        }

        #region OpenQuant3接口中的新方法
        public void RegisterOrder(NewOrderSingle order)
        {
        }
        #endregion
    }
}
